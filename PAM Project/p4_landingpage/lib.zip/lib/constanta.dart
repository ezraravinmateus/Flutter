import 'package:flutter/material.dart';

//Color Set
Color colorPrimary = Color(0xFF7517b0);

//Api Url

String baseUrl = "https://www.generasiterpilih.or.id/mobapps/flutter/";

String sliderAtas = "a_get_menu_adv.php";
String contentProduct = "a_get_menu_prd.php";

Map<String, dynamic> bioAccount = <String, dynamic>{'x1': 'a', 'x2': 'a'};
