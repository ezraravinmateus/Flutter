import 'package:flutter/material.dart';

//Color Set
Color colorPrimary = Color(0xFF7517b0);

//Api Url

String baseUrl = "https://www.generasiterpilih.or.id/mobapps/flutter/";

String loginUrl = "get_login.php";
